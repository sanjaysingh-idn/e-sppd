

<?php $__env->startSection('content'); ?>
<div class="row">
    <h2 class="fw-bold"><span class="text-muted fw-light py-5"></span> <?php echo e($title); ?></h2>
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <div class="text-start">
                </div>
            </div>

            <div class="card-body">
                <table id="table" class="table table-hover" width="100%">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode</th>
                            <th>Maksud</th>
                            <th>Alasan Ditolak</th>
                            <th>Tujuan</th>
                            <th>Tanggal</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(isset($laporan)): ?>
                        <?php
                        $no = 1;
                        ?>
                        <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td>
                                <?php echo e($item->kode_spd); ?>

                            </td>
                            <td>
                                <?php echo e($item->maksud); ?>

                            </td>
                            <td>
                                <?php echo e($item->keterangan); ?>

                            </td>
                            <td class="text-nowrap">
                                <br>
                                Kabupaten : <strong><?php echo e($item->r_provinsi->nama_provinsi); ?></strong>
                                <br>
                                Kota : <strong><?php echo e($item->r_kota->nama_kota); ?></strong>
                            </td>
                            <td>
                                <?php echo e(date('d M Y', strtotime($item->tanggal_mulai))); ?>

                                -
                                <?php echo e(date('d M Y', strtotime($item->tanggal_pulang))); ?>

                            </td>
                            <td>
                                <div class="row">
                                    <div class="col-12">
                                        <button class="btn btn-xs btn-info" data-bs-toggle="modal" data-bs-target="#modalDetail<?php echo e($item->id); ?>"><i class="bx bx-info-square me-1"></i> Detail</button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!--/ Spd Profile Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modals'); ?>

<?php if(isset($laporan)): ?>

<?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalDetail<?php echo e($item->id); ?>" tabindex="-1" aria-modal="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-info pb-3">
                <h5 class="modal-title text-white" id="modalDetailTitle">Detail Surat Perjalanan Dinas</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <small class="mb-4">Diinput pada : <?php echo e(date("d M Y, G:i:s", strtotime($item->created_at))); ?> (<?php echo e($item->created_at->diffForHumans()); ?>)</small>
                        <br>
                        <div class="table-responsive">
                            <table id="table-modal" class="table table-bordered w-100">
                                <thead class="bg-info">
                                    <tr>
                                        <th colspan="2" class="text-white">Detail SPD</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="text-capitalize">
                                        <td class="fw-bold">Ditolak Oleh</td>
                                        <td><?php echo e($item->r_user->name); ?> - <?php echo e($item->r_user->role); ?> - <?php echo e($item->r_user->golongan->golongan_name); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Kode SPD</td>
                                        <td><?php echo e($item->kode_spd); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Maksud</td>
                                        <td><?php echo e($item->maksud); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Diinput oleh</td>
                                        <td><?php echo e($item->input_by); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Jenis Perjalanan</td>
                                        <td><?php echo e($item->jenis_perjalanan); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Jenis Transportasi</td>
                                        <td><?php echo e($item->jenis_transportasi); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Tujuan</td>
                                        <td>
                                            Provinsi : <?php echo e($item->r_provinsi->nama_provinsi); ?>

                                            <br>
                                            Kabupaten/Kota : <?php echo e($item->r_kota->nama_kota); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Alasan Ditolak</td>
                                        <td><?php echo e($item->keterangan); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Jenis Perjalanan</td>
                                        <td><?php echo e($item->jenis_perjalanan); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Tanggal Berangkat</td>
                                        <td><?php echo e(date('d F Y', strtotime($item->tanggal_mulai))); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Tanggal Pulang</td>
                                        <td><?php echo e(date('d F Y', strtotime($item->tanggal_pulang))); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Lama</td>
                                        <td>
                                            <?php echo e($item->lama); ?> Hari
                                            <br>
                                            <?php echo e($item->malam); ?> Malam
                                        </td>
                                    </tr>
                                    <hr>
                                    <tr>
                                        <td class="fw-bold">Status Terakhir</td>
                                        <td><?php echo e($item->status_spd); ?></td>
                                    </tr>
                                    <?php if($item->verifikasi_pada): ?>
                                    <tr>
                                        <td class="fw-bold">Verifikasi Penanggung Jawab Kegiatan</td>
                                        <td>
                                            <p>Verifikasi Pada : <?php echo e(date("d M Y", strtotime($item->verifikasi_pada))); ?></p>
                                            <p>Verifikasi Oleh : <?php echo e($item->verifikasi_oleh); ?></p>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php if($item->verifikasi_pelaksanaan_pada): ?>
                                    <tr>
                                        <td class="fw-bold">Verifikasi Penanggung Jawab Kegiatan</td>
                                        <td>
                                            <p>Verifikasi Pada : <?php echo e(date("d M Y", strtotime($item->verifikasi_pelaksanaan_pada))); ?></p>
                                            <p>Verifikasi Oleh : <?php echo e($item->verifikasi_pelaksanaan_oleh); ?></p>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Close
                </button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function(){
        $('#table').DataTable({
            // "dom": 'rtip',
            'responsive': true,
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\WebProgramming\LARAVEL\perjadin\resources\views/dashboard/laporan/laporanSelesai.blade.php ENDPATH**/ ?>