

<?php $__env->startSection('content'); ?>
<div class="row">
    
<h2 class="fw-bold"><span class="text-muted fw-light py-5"></span> <?php echo e($title); ?></h2>
<div class="col-12">
    <div class="card card-action mb-4">
        <div class="card-body">
            <div class="d-flex align-items-start align-items-sm-center gap-4">
                <div class="button-wrapper">
                    <form action="<?php echo e(route('spd.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="input_by" value="<?php echo e(Auth::user()->name); ?>">
                        <div class="alert alert-warning" role="alert">
                            <strong>Hiraukan</strong> jika tidak ada surat undangan
                        </div>
                        <div class="">
                            <label for="kode_spd" class="form-label">Surat Undangan</label>
                        </div>
                        <img id="preview" width="200" class="img-thumbnail mb-3">
                        <label for="fileInput" class="btn btn-warning me-2 mb-4" tabindex="0">
                            <span class="d-none d-sm-block">Upload Surat Undangan</span>
                            <i class="bx bx-upload d-block d-sm-none"></i>
                            <input type="file" class="account-file-input <?php $__errorArgs = ['undangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="fileInput" name="undangan" accept="image/png, image/jpeg" hidden onchange="previewImage()">
                        </label>
                        <button type="button" value="Reset" onclick="resetImage()" class="btn btn-outline-warning account-image-reset mb-4">
                            <i class="bx bx-reset d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Reset</span>
                        </button>
                        <?php $__errorArgs = ['undangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <p class="text-muted mb-0">Format JPG, PNG, JPEG, PDF Ukuran Max 2MB</p>
                </div>
            </div>
        </div>
        <hr class="my-0" />
        <div class="card-body">
            <div class="row">
                <div class="mb-3 col-md-5">
                    <label for="kode_spd" class="form-label">kode spd</label>
                    <input class="form-control <?php $__errorArgs = ['kode_spd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" id="kode_spd" name="kode_spd" value="<?php echo e(old('kode_spd')); ?>" autofocus />
                    <?php $__errorArgs = ['kode_spd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3 col-md-4">
                    <label for="jenis_perjalanan" class="form-label">jenis perjalanan</label><br>
                    <div class="btn-group" role="group">
                        <?php $__currentLoopData = $jenis_perjalanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="radio" class="btn-check" name="jenis_perjalanan" value="<?php echo e($jp); ?>" id="<?php echo e($jp); ?>" autocomplete="off">
                        <label class="btn btn-outline-primary text-capitalize" for="<?php echo e($jp); ?>"><?php echo e($jp); ?></label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php $__errorArgs = ['jenis_perjalanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <br>
                    <div class="text-small text-danger mt-1">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3 col-md-3">
                    <label for="jenis_transportasi" class="form-label">jenis Transportasi</label><br>
                    <div class="btn-group" role="group">
                        <?php $__currentLoopData = $jenis_transportasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="radio" class="btn-check" name="jenis_transportasi" value="<?php echo e($jt); ?>" id="<?php echo e($jt); ?>" autocomplete="off">
                        <label class="btn btn-outline-warning text-capitalize" for="<?php echo e($jt); ?>"><?php echo e($jt); ?></label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php $__errorArgs = ['jenis_transportasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <br>
                    <div class="text-small text-danger mt-1">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3 col-md-12">
                    <div class="row">
                        <div class="mb-3 col-md-6">
                            <label for="provinsi" class="form-label">provinsi</label>
                            <select id="provinsi" class="form-select <?php $__errorArgs = ['provinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="provinsi" required style="width: 100%">

                            </select>
                            <?php $__errorArgs = ['provinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-md-6">
                            <label for="kota" class="form-label">Kota</label>
                            <select id="kota" class="form-select <?php $__errorArgs = ['kota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kota" required style="width: 100%">
                                <option value="" class="text-capitalize">--Pilih Kabupaten/Kota--</option>
                            </select>
                            <?php $__errorArgs = ['kota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="mb-3 col-12">
                    <label for="maksud" class="form-label">Maksud</label>
                    <textarea class="form-control <?php $__errorArgs = ['maksud'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" id="maksud" name="maksud" /><?php echo e(old('maksud')); ?></textarea>
                    <?php $__errorArgs = ['maksud'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3 col-12">
                    <div class="row">
                        <div class="col-6">
                            <div class="row">
                                <div class="mb-3 col-sm-6">
                                    <label for="tanggal_mulai" class="form-label">Tanggal Mulai</label>
                                    <input class="form-control <?php $__errorArgs = ['tanggal_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="date" id="tanggal_mulai" name="tanggal_mulai" min="<?php echo e(date('Y-m-d')); ?>" value="<?php echo e(old('tanggal_mulai')); ?>" />
                                    <?php $__errorArgs = ['tanggal_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3 col-sm-6">
                                    <label for="tanggal_pulang" class="form-label">Tanggal Pulang</label>
                                    <input class="form-control <?php $__errorArgs = ['tanggal_pulang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="date" id="tanggal_pulang" name="tanggal_pulang" min="<?php echo e(date('Y-m-d')); ?>" value="<?php echo e(old('tanggal_pulang')); ?>" />
                                    <?php $__errorArgs = ['tanggal_pulang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="row">
                                <div class="mb-3 col-sm-6">
                                    <label for="lama" class="form-label">hari</label>
                                    <div class="input-group">
                                        <input type="number" class="form-control <?php $__errorArgs = ['lama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="2" aria-label="1" name="lama" value="<?php echo e(old('lama')); ?>">
                                        <span class="input-group-text" id="basic-addon13">hari</span>
                                        <?php $__errorArgs = ['lama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="mb-3 col-sm-6">
                                    <label for="malam" class="form-label">malam</label>
                                    <div class="input-group">
                                        <input type="number" class="form-control <?php $__errorArgs = ['malam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="1" aria-label="1" name="malam" value="<?php echo e(old('malam')); ?>">
                                        <span class="input-group-text" id="basic-addon13">Malam</span>
                                        <?php $__errorArgs = ['malam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <label for="users" class="form-label">Tambah Peserta (Max : 5 Orang)</label><br>
                            <small class="text-danger">Jika peserta tidak ada, peserta sedang memiliki SPD yang sedang berjalan</small>
                            <select id="users" class="form-select <?php $__errorArgs = ['users'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="users[]" multiple style="width: 100%">
                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!$item->spd_id): ?>
                                <option value="<?php echo e($item->id); ?>" class="text-capitalize">
                                    <?php echo e($item->name); ?> | <strong><?php echo e($item->nip); ?></strong> | <?php echo e($item->golongan->golongan_name); ?>

                                </option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['users'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div id="selected-users-container"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mt-2">
                <button type="submit" class="btn btn-primary me-2" <?php if(!Auth::user()->spd_id): ?> <?php echo e(""); ?> <?php else: ?> disabled <?php endif; ?>><i class="bx bx-send"></i> Kirim</button>
                <button type="reset" class="btn btn-outline-secondary">Cancel</button>
            </div>
            <small class="text-danger">
                <?php if(Auth::user()->spd_id): ?> <?php echo e("Anda masih memiliki SPD yang sedang berjalan"); ?> <?php endif; ?>
            </small>
            </form>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function previewImage() {
        // Get the preview image element and the file input element
        var preview = document.getElementById("preview");
        var fileInput = document.getElementById("fileInput");
    
        // Check if a file was selected
        if (fileInput.files && fileInput.files[0]) {
        // Create a new FileReader object
        var reader = new FileReader();
    
        // Set the onload function for the reader
        reader.onload = function(e) {
        // Set the src attribute of the preview image to the result of the reader
        preview.setAttribute("src", e.target.result);
        };
    
        // Read the selected file as a data URL
        reader.readAsDataURL(fileInput.files[0]);
        } else {
            // If no file was selected, clear the preview image
            preview.setAttribute("src", "");
            }
        }
    
    function resetImage() {
        // Get the preview image element and the file input element
        var preview = document.getElementById("preview");
        var fileInput = document.getElementById("fileInput");
    
        // Clear the file input value and the preview image
        fileInput.value = "";
        preview.setAttribute("src", "");
    }

    // Dropdown
    $(document).ready(function() {
        $('#provinsi').select2({
            placeholder:'--Pilih Provinsi--',
            ajax : {
                url: "<?php echo e(route('selectProv')); ?>",
                processResults: function(data){
                    // console.log($data)
                    return {
                        results: $.map(data, function(item){
                            return {
                                id: item.id,
                                text: item.nama_provinsi
                            }
                        })
                    }
                }
            }
        });

        $('#provinsi').change(function(){
            let id = $('#provinsi').val();

            $('#kota').select2({
                placeholder:'--Pilih Kabupaten/Kota--',
                ajax : {
                    url: "<?php echo e(url('selectCity')); ?>/"+ id,
                    processResults: function(data){
                        return {
                            results: $.map(data, function(item){
                                return {
                                    id: item.city_id,
                                    text: item.nama_kota
                                }
                            })
                        }
                    }
                }
            });
        })
    });

    new MultiSelectTag('users')
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\WebProgramming\LARAVEL\perjadin\resources\views/dashboard/spd/create.blade.php ENDPATH**/ ?>