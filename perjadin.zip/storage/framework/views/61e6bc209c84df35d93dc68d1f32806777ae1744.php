

<?php $__env->startSection('content'); ?>
<div class="row">
    <h2 class="fw-bold"><span class="text-muted fw-light py-5"></span> <?php echo e($title); ?></h2>
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <div class="text-start">
                    <a href="<?php echo e(route('spd.create')); ?>" class="btn btn-primary <?php if(!Auth::user()->spd_id): ?> <?php echo e(""); ?> <?php else: ?> disabled <?php endif; ?>"><i class="bx bx-plus-circle"></i> Tambah Form Pengajuan</a>
                    <br>
                    <small class="text-danger">
                        <?php if(Auth::user()->spd_id): ?> <?php echo e("Anda masih memiliki SPD yang sedang berjalan"); ?> <?php endif; ?>
                    </small>
                </div>
            </div>

            <div class="card-body">
                <table id="table" class="table table-hover" width="100%">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode</th>
                            <th>Maksud</th>
                            <th>Status</th>
                            <th>Tujuan</th>
                            <th>Tanggal</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(isset($spd)): ?>
                        <?php
                        $no = 1;
                        ?>
                        <?php $__currentLoopData = $spd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td>
                                <?php echo e($item->kode_spd); ?>

                            </td>
                            <td>
                                <?php echo e($item->maksud); ?>

                            </td>
                            <td class="text-uppercase">
                                <?php if($item->status_spd == 'usulan'): ?>
                                <span class="badge bg-label-primary me-1"><?php echo e($item->status_spd); ?></span>
                                <?php elseif($item->status_spd == 'verifikasi'): ?>
                                <span class="badge bg-label-success me-1"><?php echo e($item->status_spd); ?></span>
                                <?php elseif($item->status_spd == 'pelaksanaan'): ?>
                                <span class="badge bg-label-warning me-1"><?php echo e($item->status_spd); ?></span>
                                <?php elseif($item->status_spd == 'laporan'): ?>
                                <span class="badge bg-label-info me-1"><?php echo e($item->status_spd); ?></span>
                                <?php elseif($item->status_spd == 'selesai'): ?>
                                <span class="badge bg-label-danger me-1"><?php echo e($item->status_spd); ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="text-nowrap">
                                <br>
                                Kabupaten : <strong><?php echo e($item->r_provinsi->nama_provinsi); ?></strong>
                                <br>
                                Kota : <strong><?php echo e($item->r_kota->nama_kota); ?></strong>
                            </td>
                            <td>
                                <?php echo e(date('d M Y', strtotime($item->tanggal_mulai))); ?>

                                -
                                <?php echo e(date('d M Y', strtotime($item->tanggal_pulang))); ?>

                            </td>
                            <td>
                                <div class="row">
                                    <div class="col-12">
                                        <?php if(Auth::user()->role == 'admin'): ?>

                                        <button class="btn btn-danger " data-bs-toggle="modal" data-bs-target="#modalDelete<?php echo e($item->id); ?>"><i class="bx bx-trash me-1"></i> Delete</button>

                                        <?php endif; ?>
                                        <?php if(Auth::user()->role == 'admin' || Auth::user()->role == 'bendahara'): ?>
                                        <?php if($item->status_spd == 'pelaksanaan'): ?>

                                        <button class="btn btn-success " data-bs-toggle="modal" data-bs-target="#modalSelesai<?php echo e($item->id); ?>"><i class="bx bxs-check-circle me-1"></i> Selesai</button>

                                        <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                    <?php if(Auth::user()->role == 'penanggung jawab kegiatan'): ?>
                                    <?php if($item->status_spd == "usulan"): ?>
                                    <div class="col-12 my-1">
                                        <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#modalVerifikasi<?php echo e($item->id); ?>"><i class="bx bx-pen me-1"></i> Verifikasi</button>
                                    </div>
                                    <div class="col-12 mt-1">
                                        <button class="btn btn-danger w-100" data-bs-toggle="modal" data-bs-target="#modalTolak<?php echo e($item->id); ?>"><i class="bx bx-x-circle me-1"></i> Tolak</button>
                                    </div>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->role == 'pejabat pembuat komitmen'): ?>
                                    <?php if($item->status_spd == "verifikasi"): ?>
                                    <div class="col-12 mt-1">
                                        <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#modalPenugasan<?php echo e($item->id); ?>"><i class="bx bxs-plane-alt me-1"></i> Penugasan</button>
                                    </div>
                                    <div class="col-12 mt-1">
                                        <button class="btn btn-danger w-100" data-bs-toggle="modal" data-bs-target="#modalTolak<?php echo e($item->id); ?>"><i class="bx bx-x-circle me-1"></i> Tolak</button>
                                    </div>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->role == 'bendahara'): ?>
                                    <?php if($item->status_spd == "pelaksanaan"): ?>
                                    <div class="col-12 mt-1">
                                        <button class="btn btn-danger w-100" data-bs-toggle="modal" data-bs-target="#modalTolak<?php echo e($item->id); ?>"><i class="bx bx-x-circle me-1"></i> Tolak</button>
                                    </div>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <hr>
                                    <div class="col-12">
                                        <?php if($item->status_spd == "pelaksanaan"): ?>
                                        <a href="<?php echo e(route('nota', $item->id)); ?>" class="btn btn-xs btn-primary"><i class="bx bxs-file-jpg me-1"></i> Upload Nota</a>
                                        <button class="btn btn-xs btn-secondary" data-bs-toggle="modal" data-bs-target="#modalTiket<?php echo e($item->id); ?>"><i class="bx bx-purchase-tag me-1"></i> Tiket</button>
                                        <?php endif; ?>
                                        <button class="btn btn-xs btn-info" data-bs-toggle="modal" data-bs-target="#modalDetail<?php echo e($item->id); ?>"><i class="bx bx-info-square me-1"></i> Detail</button>
                                        <?php if($item->status_spd !== "usulan" && $item->status_spd !== "verifikasi"): ?>
                                        <button class="btn btn-xs btn-warning" data-bs-toggle="modal" data-bs-target="#modalPermintaan<?php echo e($item->id); ?>"><i class="bx bx-paperclip me-1"></i> Permintaan</button>
                                        <?php endif; ?>
                                        <?php if($item->status_spd == "pelaksanaan"): ?>
                                        <button class="btn btn-xs btn-dark" data-bs-toggle="modal" data-bs-target="#modalBerkas<?php echo e($item->id); ?>"><i class="bx bx-file me-1"></i> Cetak Berkas</button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!--/ Spd Profile Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modals'); ?>

<?php if(isset($spd)): ?>

<?php $__currentLoopData = $spd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($item->status_spd == "usulan"): ?>
<div class="modal fade" id="modalVerifikasi<?php echo e($item->id); ?>" tabindex="-1" aria-modal="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary pb-3">
                <h5 class="modal-title text-white" id="modalVerifikasiTitle">Verifikasi Surat Perjalanan Dinas</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <h4>Apakah anda yakin akan memberikan verifikasi kepada SPD dibawah ini :</h4>
                        <ul class="mt-2">
                            <li>
                                <p>Kode SPD : <b><?php echo e($item->kode_spd); ?></b></p>
                            </li>
                            <li>
                                <p>Maksud : <b><?php echo e($item->maksud); ?></b></p>
                            </li>
                            <li>
                                <p>tujuan : <b><?php echo e($item->r_kota->nama_kota); ?></b></p>
                            </li>
                            <li>
                                <p>diinput oleh : <b><?php echo e($item->input_by); ?></b></p>
                            </li>
                        </ul>
                    </div>
                    <hr>
                    <div class="col-12">
                        <div class="mb-3">
                            <form action="<?php echo e(route('verifikasiSpd', $item->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <label for="mata_anggaran" class="form-label"><b>Pilih Mata Anggaran</b></label>
                                <select class="form-select form-select-lg" name="mata_anggaran" id="mata_anggaran" required>
                                    <option value="" disabled selected>--Pilih Mata Anggaran--</option>
                                    <?php $__currentLoopData = $mak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->kode_mak); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Close
                </button>
                <button type="submit" class="btn btn-primary"><i class="bx bx-pen"></i> Vefifikasi</button>
            </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(isset($spd)): ?>

<?php $__currentLoopData = $spd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($item->status_spd == "verifikasi"): ?>
<div class="modal fade" id="modalPenugasan<?php echo e($item->id); ?>" tabindex="-1" aria-modal="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary pb-3">
                <h5 class="modal-title text-white" id="modalPenugasanTitle">Penugasan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <p><strong>Penugasan sekaligus memberikan akses berkas Perjalanan Dinas</strong></p>
                        <p>Apakah anda yakin ingin memberikan Penugasan untuk :</p>
                        <ol>
                            <?php $__currentLoopData = $permintaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($p->nama); ?> - <?php echo e($p->golongan); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>
                        <p>Kode : <strong><?php echo e($item->kode_spd); ?></strong></p>
                        <p>Maksud : <strong><?php echo e($item->maksud); ?></strong></p>
                        <p>Tujuan : <strong><?php echo e($item->r_kota->nama_kota); ?></strong></p>
                    </div>
                    <hr>
                    <div class="col-12">
                        <form action="<?php echo e(route('penugasan', $item->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <label for="bendahara" class="form-label"><b>Pilih Bendahara</b></label>
                            <select class="form-select form-select-lg" name="bendahara" id="bendahara" required>
                                <option value="" disabled selected>--Pilih Bendahara--</option>
                                <?php $__currentLoopData = $bendahara; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?> - <small><?php echo e($item->golongan->golongan_name); ?></small></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <br>
                            <div class="mb-3">
                                <label for="nomor_surat_tugas" class="form-label">Nomor Surat Tugas</label>
                                <input type="nomor_surat_tugas" class="form-control" name="nomor_surat_tugas" id="nomor_surat_tugas" aria-describedby="helpId" placeholder="Terbitkan nomor surat tugas disini" required>
                            </div>

                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Close
                </button>
                <button type="submit" class="btn btn-primary"><i class="bx bx-pen"></i> Penugasan</button>
            </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(isset($spd)): ?>

<?php $__currentLoopData = $spd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($item->status_spd == "pelaksanaan"): ?>
<div class="modal fade" id="modalSelesai<?php echo e($item->id); ?>" tabindex="-1" aria-modal="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary pb-3">
                <h5 class="modal-title text-white" id="modalSelesaiTitle">Selesai SPD</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <p><strong>SPD Dinyatakan Selesai</strong></p>
                        <p>Apakah anda yakin ingin menyelesaikan spd untuk :</p>
                        <ol>
                            <?php $__currentLoopData = $permintaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($p->nama); ?> - <?php echo e($p->golongan); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>
                        <p>Kode : <strong><?php echo e($item->kode_spd); ?></strong></p>
                        <p>Maksud : <strong><?php echo e($item->maksud); ?></strong></p>
                        <p>Tujuan : <strong><?php echo e($item->r_kota->nama_kota); ?></strong></p>
                    </div>
                    <hr>
                    <div class="col-12">
                        <form action="<?php echo e(route('selesai', $item->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="status_spd" value="selesai">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Close
                </button>
                <button type="submit" class="btn btn-primary"><i class="bx bx-pen"></i> Selesai SPD</button>
            </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(isset($spd)): ?>

<?php $__currentLoopData = $spd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalTolak<?php echo e($item->id); ?>" tabindex="-1" aria-modal="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-danger pb-3">
                <h5 class="modal-title text-white" id="modalTolakTitle">Tolak SPD</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('spd.tolak', $item->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('post'); ?>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-12">
                            <p><strong>Apakah anda yakin ingin melakukan penolakan terhadap SPD ini?</strong></p>
                            <ol>
                                <?php $__currentLoopData = $permintaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($p->nama); ?> - <?php echo e($p->golongan); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                            <p>Kode : <strong><?php echo e($item->kode_spd); ?></strong></p>
                            <p>Maksud : <strong><?php echo e($item->maksud); ?></strong></p>
                            <p>Tujuan : <strong><?php echo e($item->r_kota->nama_kota); ?></strong></p>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label for="">Alasan Penolakan</label>
                                <input type="text" class="form-control mt-2" name="keterangan" value="<?php echo e(old('keterangan')); ?>" maxlength="255" placeholder="Keterangan" required>
                                <small id="helpId" class="form-text text-muted">Masukkan Keterangan penolakan disini</small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        Close
                    </button>
                    <button type="submit" class="btn btn-danger"><i class="bx bx-x-circle"></i> Tolak Spd</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(isset($spd)): ?>

<?php $__currentLoopData = $spd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalDetail<?php echo e($item->id); ?>" tabindex="-1" aria-modal="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
            <div class="modal-header bg-info pb-3">
                <h5 class="modal-title text-white" id="modalDetailTitle">Detail Surat Perjalanan Dinas</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <small class="mb-4">Diinput pada : <?php echo e(date("d M Y, G:i:s", strtotime($item->created_at))); ?> (<?php echo e($item->created_at->diffForHumans()); ?>)</small>
                        <br>
                        <small class="mb-4">Diinput oleh : <?php echo e($item->input_by); ?></small>
                        <div class="table-responsive mt-2">
                            <table id="table-modal" class="table table-bordered w-100">
                                <thead class="bg-info">
                                    <tr>
                                        <th colspan="2" class="text-white">Detail SPD</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="fw-bold">Kode SPD</td>
                                        <td><?php echo e($item->kode_spd); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Maksud</td>
                                        <td><?php echo e($item->maksud); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Tujuan</td>
                                        <td><?php echo e($item->r_provinsi->nama_provinsi); ?> - <?php echo e($item->r_kota->nama_kota); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Status SPD</td>
                                        <td class="text-uppercase fw-bold"><?php echo e($item->status_spd); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Jenis Perjalanan</td>
                                        <td class="text-capitalize"><?php echo e($item->jenis_perjalanan); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Tanggal Berangkat</td>
                                        <td><?php echo e(date('d F Y', strtotime($item->tanggal_mulai))); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Tanggal Pulang</td>
                                        <td><?php echo e(date('d F Y', strtotime($item->tanggal_pulang))); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Lama</td>
                                        <td>
                                            <?php echo e($item->lama); ?> Hari
                                            <br>
                                            <?php echo e($item->malam); ?> Malam
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Undangan</td>
                                        <td>
                                            <?php if($item->undangan): ?>
                                            <img src="<?php echo e(asset('storage/'. $item->undangan)); ?>" class="img-thumbnail" frameborder="0">
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <p class="text-center fw-bold">DETAIL PERMINTAAN</p>
                        <div class="table-responsive text-nowrap">
                            <table class="table table-bordered">
                                <thead>
                                    <tr class="text-center align-middle">
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>Pangkat/Gol</th>
                                        <th>Nip</th>
                                        <th>Taxi</th>
                                        <th>Hotel <br>(<?php echo e($item->malam); ?> Malam)</th>
                                        <th>Tiket Pesawat</th>
                                        <th>Uang Harian <br>(<?php echo e($item->lama); ?> Hari)</th>
                                        <th>Uang Representasi</th>
                                        <th>Jumlah</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no = 1;
                                    ?>
                                    <?php $__currentLoopData = $permintaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($p->spd_id == $item->id): ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e($p->nama); ?></td>
                                        <td><?php echo e($p->golongan); ?></td>
                                        <td><?php echo e($p->nip); ?></td>
                                        <td>
                                            Rp. <?php echo e(number_format($p->biaya_taksi)); ?>

                                        </td>
                                        <td>
                                            Rp. <?php echo e(number_format($p->jumlah_biaya_penginapan)); ?>

                                        </td>
                                        <td>
                                            Rp. <?php echo e(number_format($p->tiket_pesawat)); ?>

                                        </td>
                                        <td>
                                            Rp. <?php echo e(number_format($p->jumlah_uang_harian)); ?>

                                        </td>
                                        <td>
                                            Rp. <?php echo e(number_format($p->jumlah_uang_representasi)); ?>

                                        </td>
                                        <td>
                                            Rp. <?php echo e(number_format($p->jumlah)); ?>

                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr class="fw-bold">
                                        <td colspan="4">TOTAL</td>
                                        <td>
                                            Rp. <?php echo e(number_format($permintaan->sum('biaya_taksi'))); ?>

                                        </td>
                                        <td>
                                            Rp. <?php echo e(number_format($permintaan->sum('jumlah_biaya_penginapan'))); ?>

                                        </td>
                                        <td>
                                            Rp. <?php echo e(number_format($permintaan->sum('tiket_pesawat'))); ?>

                                        </td>
                                        <td>
                                            Rp. <?php echo e(number_format($permintaan->sum('jumlah_uang_harian'))); ?>

                                        </td>
                                        <td>
                                            Rp. <?php echo e(number_format($permintaan->sum('jumlah_uang_representasi'))); ?>

                                        </td>
                                        <td>
                                            Rp. <?php echo e(number_format($permintaan->sum('jumlah'))); ?>

                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Close
                </button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(isset($spd)): ?>

<?php $__currentLoopData = $spd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalTiket<?php echo e($item->id); ?>" tabindex="-1" aria-modal="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
            <div class="modal-header bg-secondary pb-3">
                <h5 class="modal-title text-white" id="modalTiketTitle">Input Biaya Tiket Pesawat</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <p><strong>Halaman ini digunakan untuk memperbarui harga tiket pesawat</strong></p>
                        <p>Biaya tiket pesawat saat ini : <strong>Rp. <?php echo e(number_format($item->tiket_pesawat)); ?></strong></p>
                        <p>Pilih Input berdasar <strong>Standar Biaya</strong> atau <strong>Biaya Manual</strong></p>
                        <p>Upload Nota pada Tombol <strong>Upload Nota</strong></p>
                    </div>
                    <hr>
                    <div class="col-12">
                        <form action="<?php echo e(route('tiket_pesawat', $item->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                <input class="btn-check" type="radio" name="options" id="option1" value="1" checked>
                                <label class="btn btn-outline-primary" for="option1">
                                    Standar Biaya
                                </label>
                                <input class="btn-check" type="radio" name="options" id="option2" value="2">
                                <label class="btn btn-outline-primary" for="option2">
                                    Biaya Manual
                                </label>
                            </div>
                            <div class="form-group mt-3" id="selectInput">
                                <label for="select">Pilih Harga Tiket</label>
                                <select class="form-control mt-2" id="select" name="tiket_pesawat">
                                    <option value="" disabled selected>--Pilih Tiket Pesawat--</option>
                                    <?php $__currentLoopData = $data_tiket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->besaran); ?>"><?php echo e($item->asal); ?> - <small><?php echo e($item->tujuan); ?> : <b>Rp. <?php echo e(number_format($item->besaran)); ?></b></small></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group d-none mt-3" id="textInput">
                                <label for="text">Biaya Tiket Manual</label>
                                <div class="input-group mt-2">
                                    <span class="input-group-text">Rp</span>
                                    <input type="text" class="form-control" name="tiket_pesawat_manual" placeholder="Masukkan biaya tiket">
                                </div>
                            </div>
                            
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Close
                </button>
                <button type="submit" class="btn btn-secondary"><i class="bx bx-purchase-tag"></i> Input Biaya Tiket</button>
            </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(isset($spd)): ?>

<?php $__currentLoopData = $spd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($item->status_spd !== "usulan" && $item->status_spd !== "verifikasi"): ?>
<div class="modal fade" id="modalPermintaan<?php echo e($item->id); ?>" tabindex="-1" aria-modal="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <a href="<?php echo e(route('cetak.permintaan', $item->id)); ?>" target="_blank" class="btn btn-warning"><i class="bx bx-printer"></i> Cetak Permintaan</a>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <div class="head">
                            <div class="row">
                                <div class="col-12 text-center text-uppercase">
                                    <p>NOMINATIF PERJALANAN DINAS</p>
                                    <p>DALAM RANGKA <?php echo e($item->maksud); ?></p>
                                    <p>TA. <?php echo e(date('Y')); ?></p>
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-12">
                                    <p>Kode Akun : <?php echo e($item->mak->kode_mak); ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <p class="text-center">PERMINTAAN</p>
                                    <div class="table-responsive text-nowrap">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr class="text-center align-middle">
                                                    <th>No</th>
                                                    <th>Nama</th>
                                                    <th>Pangkat/Gol</th>
                                                    <th>Tujuan</th>
                                                    <th>Tanggal</th>
                                                    <th>Lama Perjalanan</th>
                                                    <th>Taxi</th>
                                                    <th>Hotel <br>(<?php echo e($item->malam); ?> Malam)</th>
                                                    <th>Tiket Pesawat</th>
                                                    <th>Uang Harian <br>(<?php echo e($item->lama); ?> Hari)</th>
                                                    <th>Uang Representasi</th>
                                                    <th>Jumlah</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $no = 1;
                                                ?>
                                                <?php $__currentLoopData = $permintaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($p->spd_id == $item->id): ?>
                                                <tr>
                                                    <td><?php echo e($no++); ?></td>
                                                    <td><?php echo e($p->nama); ?></td>
                                                    <td><?php echo e($p->golongan); ?></td>
                                                    <td><?php echo e($item->r_kota->nama_kota); ?></td>
                                                    <td>
                                                        <?php echo e(date('d F Y', strtotime($item->tanggal_mulai))); ?>

                                                        - <?php echo e(date('d F Y', strtotime($item->tanggal_pulang))); ?>

                                                    </td>
                                                    <td><?php echo e($item->lama); ?> hari</td>
                                                    <td>
                                                        Rp. <?php echo e(number_format($p->biaya_taksi)); ?>

                                                    </td>
                                                    <td>
                                                        Rp. <?php echo e(number_format($p->jumlah_biaya_penginapan)); ?>

                                                    </td>
                                                    <td>
                                                        Rp. <?php echo e(number_format($p->tiket_pesawat)); ?>

                                                    </td>
                                                    <td>
                                                        Rp. <?php echo e(number_format($p->jumlah_uang_harian)); ?>

                                                    </td>
                                                    <td>
                                                        Rp. <?php echo e(number_format($p->jumlah_uang_representasi)); ?>

                                                    </td>
                                                    <td>
                                                        Rp. <?php echo e(number_format($p->jumlah)); ?>

                                                    </td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                            <tfoot>
                                                <tr class="fw-bold">
                                                    <td colspan="6">TOTAL</td>
                                                    <td>
                                                        Rp. <?php echo e(number_format($permintaan->sum('biaya_taksi'))); ?>

                                                    </td>
                                                    <td>
                                                        Rp. <?php echo e(number_format($permintaan->sum('jumlah_biaya_penginapan'))); ?>

                                                    </td>
                                                    <td>
                                                        Rp. <?php echo e(number_format($permintaan->sum('tiket_pesawat'))); ?>

                                                    </td>
                                                    <td>
                                                        Rp. <?php echo e(number_format($permintaan->sum('jumlah_uang_harian'))); ?>

                                                    </td>
                                                    <td>
                                                        Rp. <?php echo e(number_format($permintaan->sum('jumlah_uang_representasi'))); ?>

                                                    </td>
                                                    <td>
                                                        Rp. <?php echo e(number_format($permintaan->sum('jumlah'))); ?>

                                                    </td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="row my-4">
                                <div class="col-12">
                                    <p class="mb-0">Catatan : </p>
                                    <p>* Sanggup mempertanggungjawabkan beserta seluruh dokumen paling lambat 5 hari kerja setelah pelaksanaan kegiatan</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <?php if($item->verifikasi_oleh !== null): ?>
                                    <p class="mb-0 text-white">.</p>
                                    <p class="mb-0 text-capitalize"><?php echo e($item->pj->role); ?></p>
                                    <p><?php echo e($item->pj->jabatan->jabatan_name); ?></p>
                                    <br>
                                    <br>
                                    <p class="mb-0 text-decoration-underline"><?php echo e($item->pj->name); ?></p>
                                    <p>NIP. <?php echo e($item->pj->nip); ?></p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-4">
                                    <p class="mb-0 text-white">.</p>
                                    <p class="mb-0 text-white">.</p>
                                    <p class="text-capitalize"><?php echo e($item->bd->role); ?></p>
                                    <br>
                                    <br>
                                    <p class="mb-0 text-decoration-underline"><?php echo e($item->bd->name); ?></p>
                                    <p>NIP. <?php echo e($item->bd->nip); ?></p>
                                </div>
                                <div class="col-4">
                                    <p class="mb-0">Jakarta, <?php if($item->verifikasi_pelaksanaan_pada !== null): ?>
                                        <?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->verifikasi_pelaksanaan_pada)->locale('id')->isoFormat('D MMMM Y')); ?>

                                        <?php endif; ?></p>
                                    <p class="mb-0">A.n. Kuasa Pengguna Anggaran</p>
                                    <p class="text-capitalize"><?php echo e($item->ppk->role); ?></p>
                                    <br>
                                    <br>
                                    <p class="mb-0 text-decoration-underline"><?php echo e($item->ppk->name); ?></p>
                                    <p>NIP. <?php echo e($item->ppk->nip); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Close
                </button>
                <a href="<?php echo e(route('cetak.permintaan', $item->id)); ?>" target="_blank" class="btn btn-warning"><i class="bx bx-printer"></i> Cetak Permintaan</a>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(isset($spd)): ?>

<?php $__currentLoopData = $spd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($item->status_spd == "pelaksanaan"): ?>
<div class="modal fade" id="modalBerkas<?php echo e($item->id); ?>" tabindex="-1" aria-modal="true">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-dark pb-3">
                <h5 class="modal-title text-white" id="modalVerifikasiTitle">Daftar Cetak Berkas</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <p>Cetak Surat Tugas : <br><a href="<?php echo e(route('cetak.suratTugas', $item->id)); ?>" target="_blank" class="btn btn-dark"><i class="bx bx-file"></i> Cetak Surat Tugas</a></p>
                    </div>
                    <div class="col-12">
                        <p>Cetak Surat Perjalanan Dinas : <br><a href="<?php echo e(route('cetak.suratSpd', $item->id)); ?>" target="_blank" class="btn btn-dark"><i class="bx bx-file"></i> Cetak Surat Perjalanan Dinas</a></p>
                    </div>
                    <div class="col-12">
                        <p>Cetak Kwitansi : <br><a href="<?php echo e(route('cetak.kwitansi', $item->id)); ?>" target="_blank" class="btn btn-dark"><i class="bx bx-file"></i> Cetak Kwitansi</a></p>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Close
                </button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(isset($spd)): ?>

<?php $__currentLoopData = $spd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalDelete<?php echo e($item->id); ?>" tabindex="-1" aria-modal="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalDeleteTitle">Delete Biaya Representasi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('spd.destroy', $item->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-12">
                            <div class="alert alert-danger" role="alert">
                                <h4 class="alert-heading">Apakah anda yakin ingin menghapus data pengajuan</h4>
                                <p><strong><?php echo e($item->kode_spd); ?></strong> dengan maksud <strong><?php echo e($item->maksud); ?></strong> ?</p>
                                <hr>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        Close
                    </button>
                    <button type="submit" class="btn btn-danger"><i class="bx bx-trash"></i> Hapus data</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function(){
        $('#table').DataTable({
            // "dom": 'rtip',
            'responsive': true,
        });
    });

    $(document).ready(function() {
    $('input[name="options"]').click(function() {
    if ($('#option1').is(':checked')) {
    $('#selectInput').removeClass('d-none');
    $('#textInput').addClass('d-none');
    } else {
    $('#selectInput').addClass('d-none');
    $('#textInput').removeClass('d-none');
    }
    });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\WebProgramming\LARAVEL\perjadin\resources\views/dashboard/spd/index.blade.php ENDPATH**/ ?>