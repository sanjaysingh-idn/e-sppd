

<?php $__env->startSection('content'); ?>
<div class="row">
    <?php if($errors->any()): ?>
    <?php dd($errors); ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <h2 class="fw-bold"><span class="text-muted fw-light py-5"><?php echo e($title); ?></span> | </h2>
    <div class="row">
        <div class="col mb-3">
            <a href="/spd" class="btn btn-secondary"><i class="bx bx-left-arrow"></i> Kembali</a>
        </div>
    </div>
    <div class="col-12">
        <div class="card card-action mb-4">
            <div class="card-header align-items-center">
                <h4 class="card-action-title mb-0">PERMINTAAN SPD</h4>
            </div>
            <hr>
            <div class="card-body">
                <div class="row text-dark">
                    <div class="col-6">
                        <table class="table table-borderless">
                            <tr>
                                <td>Nama</td>
                                <td><?php echo e($permintaan->nama); ?></td>
                            </tr>
                            <tr>
                                <td>Nip</td>
                                <td><?php echo e($permintaan->nip); ?></td>
                            </tr>
                            <tr>
                                <td>Golongan</td>
                                <td><?php echo e($permintaan->golongan); ?></td>
                            </tr>
                            <tr>
                                <td>Tujuan</td>
                                <td><?php echo e($permintaan->r_kota->nama_kota); ?> (<?php echo e($permintaan->r_provinsi->nama_provinsi); ?>)</td>
                            </tr>
                            <tr>
                                <td>Lama</td>
                                <td><?php echo e($permintaan->lama); ?> Hari</td>
                            </tr>
                            <tr>
                                <td>Malam</td>
                                <td><?php echo e($permintaan->malam); ?> Malam</td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-6">
                        <table class="table table-borderless">
                            <tr>
                                <td>Biaya Taksi</td>
                                <td>Rp. <?php echo e(number_format($permintaan->biaya_taksi)); ?></td>
                            </tr>
                            <tr>
                                <td>Biaya Penginapan</td>
                                <td>Rp. <?php echo e(number_format($permintaan->jumlah_biaya_penginapan)); ?></td>
                            </tr>
                            <tr>
                                <td>Tiket Pesawat</td>
                                <td>Rp. <?php echo e(number_format($permintaan->tiket_pesawat)); ?></td>
                            </tr>
                            <tr>
                                <td>Uang Harian</td>
                                <td>Rp. <?php echo e(number_format($permintaan->jumlah_uang_harian)); ?></td>
                            </tr>
                            <tr>
                                <td>Uang Representasi</td>
                                <td>Rp. <?php echo e(number_format($permintaan->jumlah_uang_representasi)); ?></td>
                            </tr>
                            <tr class="fw-bold">
                                <td>TOTAL</td>
                                <td>Rp. <?php echo e(number_format($permintaan->jumlah)); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-4 col-lg-5 col-md-5">
        <div class="card mb-4">
            <form action="<?php echo e(route('add_nota')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="text" value="<?php echo e($permintaan->id); ?>" name="permintaan_id" hidden>
                <div class="card-body">
                    <div class="label">
                        <label for="kode_spd" class="form-label">Foto Nota</label>
                    </div>
                    <img id="preview" width="200" class="img-thumbnail mb-3">
                    <label for="fileInput" class="btn btn-warning me-2 mb-4" tabindex="0">
                        <span class="d-none d-sm-block">Upload Foto Nota</span>
                        <i class="bx bx-upload d-block d-sm-none"></i>
                        <input type="file" class="account-file-input <?php $__errorArgs = ['foto_nota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="fileInput" name="foto_nota" accept="image/png, image/jpeg" hidden onchange="previewImage()">
                    </label>
                    <button type="button" value="Reset" onclick="resetImage()" class="btn btn-outline-warning account-image-reset mb-4">
                        <i class="bx bx-reset d-block d-sm-none"></i>
                        <span class="d-none d-sm-block">Reset</span>
                    </button>
                    <?php $__errorArgs = ['foto_nota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <p class="text-muted mb-0">Format JPG, PNG, JPEG, PDF Ukuran Max 2MB</p>s
                    <hr>
                    <label for="ket_nota" class="form-label">Keterangan Nota</label>
                    <input class="form-control <?php $__errorArgs = ['ket_nota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" id="ket_nota" name="ket_nota" value="<?php echo e(old('ket_nota')); ?>" autofocus required />
                    <?php $__errorArgs = ['ket_nota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary me-2">Simpan Nota</button>
                    <button type="reset" class="btn btn-outline-secondary">Cancel</button>
                </div>
            </form>
        </div>
    </div>
    <div class="col-xl-8 col-lg-7 col-md-7">
        <div class="card card-action mb-4">
            <div class="card-header align-items-center">
                <h4 class="card-action-title mb-0"><i class='bx bxs-file-image'></i>Daftar Nota</h4>
            </div>
            <div class="card-body">
                <?php $__currentLoopData = $nota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($item->ket_nota); ?></h5>
                            <h6 class="card-subtitle text-muted"><?php echo e($item->created_at); ?></h6>
                        </div>
                        <img class="img-fluid" src="<?php echo e(asset('storage/'. $item->foto_nota)); ?>" alt="Card image cap">
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <hr class="my-0" />
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    function previewImage() {
        // Get the preview image element and the file input element
        var preview = document.getElementById("preview");
        var fileInput = document.getElementById("fileInput");
    
        // Check if a file was selected
        if (fileInput.files && fileInput.files[0]) {
        // Create a new FileReader object
        var reader = new FileReader();
    
        // Set the onload function for the reader
        reader.onload = function(e) {
        // Set the src attribute of the preview image to the result of the reader
        preview.setAttribute("src", e.target.result);
        };
    
        // Read the selected file as a data URL
        reader.readAsDataURL(fileInput.files[0]);
        } else {
            // If no file was selected, clear the preview image
            preview.setAttribute("src", "");
            }
        }
    
    function resetImage() {
        // Get the preview image element and the file input element
        var preview = document.getElementById("preview");
        var fileInput = document.getElementById("fileInput");
    
        // Clear the file input value and the preview image
        fileInput.value = "";
        preview.setAttribute("src", "");
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\WebProgramming\LARAVEL\perjadin\resources\views/dashboard/nota/index.blade.php ENDPATH**/ ?>